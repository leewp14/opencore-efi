# CsrDecode
Small py script to show what different CsrActiveConfig values enable/disable
