# OCConfigCompare
Python script to compare two plists and list missing keys in either.
